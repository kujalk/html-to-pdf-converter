import json
import pdfkit
import boto3
import os

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # TODO implement
    
    try:
        config = pdfkit.configuration(wkhtmltopdf="/opt/bin/wkhtmltopdf")
        body=json.loads(event.get('body'))
        
        print("Function started")
        print(f"PDF Name - {body.get('pdf_name')}")
        print(f"HTML string - {body.get('html_string')}")
        
        temp_file_path= f"/tmp/{body.get('pdf_name')}"
        pdfkit.from_string(body.get('html_string'), temp_file_path,configuration=config)
        s3_client.upload_file(temp_file_path, os.getenv("bucket_name"), body.get('pdf_name'),ExtraArgs={'ContentType':'application/pdf'})
        
        return {
    'statusCode': 201,
    'headers': {'Content-Type': 'application/json'},
    'body': json.dumps("Success")
}
        
    except Exception as e:
        print(f"Error in main - {e}")
        return {
    'statusCode': 400,
    'headers': {'Content-Type': 'application/json'},
    'body': json.dumps(f"Error in main - {e}")
}
